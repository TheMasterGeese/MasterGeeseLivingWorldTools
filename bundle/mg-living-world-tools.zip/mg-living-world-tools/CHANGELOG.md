# My Module

## Release 1.0.0
Initial tag. Each time a new version is released fill this out with any changes.