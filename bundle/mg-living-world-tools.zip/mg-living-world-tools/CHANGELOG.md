# MasterGeeseLivingWorldTools

## 1.0.0
I- Initial Release

## 1.0.1
- Fixed shields on README pointing to the wrong repository.
- Added listing of modules that are part of the MG Living World pack to README.
- Added sample handlebars folder and file.
- Added descriptions of fields to fill out in module.json to README.
- Fixed minimum core version being incorrect (even though this is not a module meant to be installed, other modules will use this as a template.)
- Removed dangling reference to gulp-tabify 