# My Module

## Release 1.0.1 (yyyy-dd-mm)
- A simple list
- Of changes

## Release 1.0.0 (yyyy-dd-mm)
- A simple list
- Of changes

## Pre-Release 0.1.0 (yyyy-dd-mm)
- A simple list
- Of changes